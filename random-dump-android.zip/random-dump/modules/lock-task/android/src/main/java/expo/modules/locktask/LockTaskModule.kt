package expo.modules.locktask

import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class LockTaskModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("LockTask")

    Function("start") {
      val activity = appContext.currentActivity
      if (activity != null) {
        activity.runOnUiThread {
          try { activity.startLockTask() } catch (e: Exception) {}
        }
      }
    }

    Function("stop") {
      val activity = appContext.currentActivity
      if (activity != null) {
        activity.runOnUiThread {
          try { activity.stopLockTask() } catch (e: Exception) {}
        }
      }
    }
  }
}
