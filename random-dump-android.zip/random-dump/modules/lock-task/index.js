import { requireOptionalNativeModule } from 'expo-modules-core';
const Native = requireOptionalNativeModule('LockTask');
export const lockPhone = () => { try { Native && Native.start(); } catch (e) {} };
export const unlockPhone = () => { try { Native && Native.stop(); } catch (e) {} };
