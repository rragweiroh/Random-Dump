# Random Dump (Android)

## Easiest: let GitHub build the APK for you (no Android Studio)
1. Create a free GitHub account and a new repository named random-dump.
2. Upload everything in this folder to it (keep the .github folder).
3. Open the repo > Actions > "Build Android APK" > Run workflow. Wait about 10 minutes.
4. Open the finished run, download "random-dump-apk", unzip it, and open app-release.apk on your phone.
   (Android will ask you to allow installing from this source. Allow it once.)

## Or build on your computer
Install Node.js and Android Studio, plug in your phone with USB debugging on, then:
  npm install
  npx expo run:android --variant release

## Focus lock
When a focus session starts, Android asks once to pin the app. Tap "Got it" / "Start".
Home and Recents are then disabled until the timer ends. Emergency exit: hold Back + Recents.
If it doesn't pin: Settings > Security > App pinning (turn on).
