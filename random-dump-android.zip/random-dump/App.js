import React, { useEffect, useRef, useState } from 'react';
import { BackHandler, Linking, StatusBar, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { activateKeepAwakeAsync, deactivateKeepAwake } from 'expo-keep-awake';
import { lockPhone, unlockPhone } from './modules/lock-task';
import html from './html';

const BASE = 'https://randomdump.local/';

export default function App() {
  const [locked, setLocked] = useState(false);
  const lockedRef = useRef(false);

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => lockedRef.current);
    return () => sub.remove();
  }, []);

  const onMessage = e => {
    const m = e.nativeEvent.data;
    if (m === 'lock') { lockedRef.current = true; setLocked(true); lockPhone(); activateKeepAwakeAsync('rd'); }
    if (m === 'unlock') { lockedRef.current = false; setLocked(false); unlockPhone(); deactivateKeepAwake('rd'); }
  };

  const onRequest = req => {
    if (req.url === BASE || req.url.startsWith('about:') || req.url.startsWith('data:')) return true;
    if (/^(https?|mailto):/.test(req.url)) { Linking.openURL(req.url); return false; }
    return true;
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      <StatusBar hidden={locked} barStyle="dark-content" backgroundColor="#fff" />
      <WebView
        source={{ html, baseUrl: BASE }}
        originWhitelist={['*']}
        onMessage={onMessage}
        onShouldStartLoadWithRequest={onRequest}
        setSupportMultipleWindows={false}
        javaScriptEnabled
        domStorageEnabled
        overScrollMode="never"
        style={{ flex: 1, backgroundColor: '#fff' }}
      />
    </View>
  );
}
